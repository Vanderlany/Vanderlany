import 'package:flutter/material.dart';
import 'package:fmvmevents/evento_notificacao.dart';
import 'package:fmvmevents/ui/pages/evento_criar_conta.dart';
import 'package:fmvmevents/ui/pages/evento_perfil.dart';
import 'package:fmvmevents/ui/pages/evento_rascunho.dart';
import 'package:fmvmevents/ui/pages/perfil.dart';
import 'package:fmvmevents/ui/pages/evento_detail.dart';
import 'package:fmvmevents/ui/pages/evento_explorar.dart';
import 'package:fmvmevents/ui/pages/evento_list.dart';

void main() {
  runApp(MaterialApp(home: (((EventsList())))));
}
