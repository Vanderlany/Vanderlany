/*/
import 'package:flutter/material.dart';
import 'package:fmvmevents/data/evento_repository.dart';
import 'package:fmvmevents/entities/entities.dart';

class MovieController{
  final EventoRepository _moviesRepository;
  MovieController(this._moviesRepository){
    fetch();
  }

  ValueNotifier<EventoRepository? >movies = ValueNotifier<EventoRepository?>(null);
  EventoRepository? _cacheMovies;

  onChanged(String value){
    List<EventoRepository> list = _cacheMovies!.listMovies.where(
      (e) => e.toString().toLowerCase().contains((value.toLowerCase())),
    )
    .toList();
    movies.value = movies.value!.copyWith(listMovies: list);
  }

  fetch() async{
    movies.value =await _moviesRepository.getMovies();
    _cacheMovies = movies.value;
  }
}
*/