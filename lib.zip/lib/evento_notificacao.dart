import 'package:flutter/material.dart';

class EventoNotificacao extends StatelessWidget {
  const EventoNotificacao({Key? key}) : super(key: key);

  get crossAxisCount => null;


  @override
  Widget build(BuildContext context) {
    var onChanged;
       return Scaffold(
      backgroundColor: Color (0xFF766B6B),
       body: Column(children: [
         SizedBox(height: 50),
          Icon(
             Icons.arrow_forward,
              color: Colors.black,
               ),
         Text("Notificações",
        style: TextStyle(fontSize: 30, fontWeight: FontWeight.normal)),
        SizedBox(height: 80,),


            Text("Lembretes                                                                 data/hora",
            textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
             Container(
            alignment: Alignment.center,
           height: 100,
            width: 600,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(10)), 
        ),

             Text("                                                                            data/hora",
            textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
             Container(
            alignment: Alignment.center,
           height: 100,
            width: 600,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(10)), 
        ),

             Text("                                                                            data/hora",
            textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
             Container(
            alignment: Alignment.center,
           height: 100,
            width: 600,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(10)), 
        ),

             Text("                                                                            data/hora",
            textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
             Container(
            alignment: Alignment.center,
           height: 100,
            width: 600,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(10)), 
        ),

             Text("                                                                            data/hora",
            textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
             Container(
            alignment: Alignment.center,
           height: 100,
            width: 600,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(10)), 
        ),

             Text("                                                                            data/hora",
            textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
             Container(
            alignment: Alignment.center,
           height: 100,
            width: 600,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(10)), 
        ),

             Text("                                                                            data/hora",
            textAlign: TextAlign.right,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
             Container(
            alignment: Alignment.center,
           height: 100,
            width: 600,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(10)), 
        ),
       ]
       ));
  }
  }