class Evento {
  String banner;
  String topico;
  String title;
  String local;
  String desc;
  String detal;
  String prog;
  String programacao;
  String descricaoDoEvento;
  Evento (this.banner, this.topico,this.title, this.local,this.desc,this.detal, this.prog, this.programacao, this.descricaoDoEvento);
}