import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

 class EventoExplorar extends StatelessWidget {
const EventoExplorar({ Key? key }) : super(key: key);

  get backgroundColor => null;

@override
Widget build (BuildContext context) {
return Scaffold(
    backgroundColor: Color(0xFF0B07C8),
    body: Column(
      children: [
        Image.network(
         "https://sabermatematica.com.br/wp-content/uploads/2018/04/triangulo-equilatero.png"),

         SizedBox(height: 100,),
          Text("Explore eventos                                         perto de você",
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          SizedBox(height: 100,),
        
        
         Text("Encontre facilmente eventos ao seu redor.                                                Usar o mapa requer o uso da localização",
         textAlign: TextAlign.center,
         style: TextStyle(fontSize: 25, fontWeight: FontWeight.normal)),
         SizedBox(height: 100,),
    
     SizedBox(height: 1,),
         Container(
              child: Text("Ver eventos perto de mim",
             style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.normal),  
             
            ), 
            alignment: Alignment.center,
            height: 100,
            width: 500,
           decoration: BoxDecoration(
             color: Color(0xFF5A57F8),
             border: Border.all(
               color: Colors.white,
              
             ),
            borderRadius: BorderRadius.circular(30)), 
  
              
         ),
          SizedBox(height: 40,),
        Container(
            child: Text("Escolher uma cidade", 
           style: TextStyle( fontSize: 20, fontWeight: FontWeight.normal),     
            ),
            alignment: Alignment.center,
            height: 100,
            width: 500,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5.0, 
             ),
            borderRadius: BorderRadius.circular(30)), 
    
          ),
      ]),
        bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        backgroundColor: Color(0xFF0B07C8),
        items: const[
                BottomNavigationBarItem(icon: Icon(Icons.home, color: Colors.white, size: 40), label: "Home", backgroundColor: Color(0xFF0B07C8)),
        BottomNavigationBarItem(
            icon: Icon(Icons.explore, color: Colors.white, size: 40), label: "Explorar",),
        BottomNavigationBarItem(
            icon: Icon(Icons.add_circle, color: Colors.white,size: 40), label: "Criar eventos"),
             BottomNavigationBarItem(
            icon: Icon(Icons.notifications, color: Colors.white, size: 40), label: "Notificação"),
             BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.white, size: 40), label: "Perfil")
            
                    
        
      ],
    ),
  );
}
 }