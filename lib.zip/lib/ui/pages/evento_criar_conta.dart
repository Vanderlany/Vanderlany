import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fmvmevents/entities/entities.dart';
import 'package:fmvmevents/ui/pages/evento_rascunho.dart';

class EventoCriarCont extends StatelessWidget {
  const EventoCriarCont({Key? key}) : super(key: key);

  get crossAxisCount => null;


  @override
  Widget build(BuildContext context) {
    var onChanged;
       return Scaffold(
      backgroundColor: Color (0xFF766B6B),
       body: Column(children: [
         SizedBox(
           height: 140,
         ),
         Container(
            child: Text("Criar Evento",
             style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold)),
            alignment: Alignment.center,
            height: 100,
            width: 500,
         
          ),
      Text("Nome do Evento                                                                      ",
         style: TextStyle( fontSize: 20, fontWeight: FontWeight.normal)),
          Align(
        alignment: Alignment.bottomRight),
        SizedBox(height: 10,),
              Container(       
            height: 50,
            width: 500,
              decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,   
             ),
              borderRadius: BorderRadius.circular(10)), 
              ),
              SizedBox(height: 25,),
              Text("Data e horário de ínicio",
                 style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
                 SizedBox(height: 10,),
                 Container(
                   child: Text("__/__/____ ás __:__",
                   style: TextStyle(fontSize: 20),
                   ),
                  height: 35,
            width: 180,
              decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,   
             ),
              borderRadius: BorderRadius.circular(10)), 
              ),
               
                 SizedBox(height: 25,),
              Text("Data e horário de ínicio",
                 style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
                 SizedBox(height: 10,),
                 Container(
                   child: Text("__/__/____ ás __:__",
                   style: TextStyle(fontSize: 20),
                   ),
                  height: 35,
            width: 180,
              decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,   
              ),
              borderRadius: BorderRadius.circular(10)), 
              ),

             SizedBox(height: 70,),
              Text("Categoria principal                ",
               style: TextStyle(fontSize: 40, fontWeight: FontWeight.normal)),


               SizedBox(height: 50,),
              Text("Produto do evento                                                              ",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.normal),
              ),
              SizedBox(height: 8,),
              Text("Adicionar perfil comercial                                                              ",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.normal),
              ),
              SizedBox(height: 190,),
               Container(
                      child: Text("                 Criar Evento",
                   style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                   ),
                  height: 70,
            width: 400,
              decoration: BoxDecoration(
             color: Colors.blueAccent,
             border: Border.all(
               color: Colors.blueAccent,
               width: 5,   
             ),
              borderRadius: BorderRadius.circular(10)), 
              ),
       ]),
             bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Color(0xFF9400D3),
        items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home, color: Colors.white, size: 40), label: "Home", backgroundColor: Color(0xFF766B6B)),
        BottomNavigationBarItem(
            icon: Icon(Icons.explore, color: Colors.white, size: 40), label: "Explorar",),
        BottomNavigationBarItem(
            icon: Icon(Icons.add_circle, color: Colors.white,size: 40), label: "Criar eventos"),
             BottomNavigationBarItem(
            icon: Icon(Icons.notifications, color: Colors.white, size: 40), label: "Notificação"),
             BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.white, size: 40), label: "Perfil")

              
       ]),
       );
  }
}