import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:fmvmevents/entities/entities.dart';

class EventoDetail extends StatelessWidget {
  final Evento evento;
  const EventoDetail(this.evento, {Key? key}) : super(key: key);

  get crossAxisCount => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFFCD92BD),
        body: Column(children: [
          Image.network(evento.banner),
          Text(evento.topico,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
          SizedBox(
            height: 100,
          ),
          SizedBox(height: 10),
          Text(evento.title,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
            Container(
           child:
            Text(evento.local,
            textAlign: TextAlign.end,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
            alignment: Alignment.center,
           height: 100,
            width: 500,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5,    
                
           ),
         borderRadius: BorderRadius.circular(30)), 
        ),
           
          SizedBox(
            height: 10,
          ),
          Text(evento.desc,
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          SizedBox(
            height: 5,
          ),
          Container(
            child: Text(evento.detal,
             style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal),     
            ),
            alignment: Alignment.center,
            height: 100,
            width: 500,
           decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5, 
             ),
            borderRadius: BorderRadius.circular(30)), 
    
          ),
          SizedBox(
            height: 10,
          ),
          Text(evento.prog,
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          SizedBox(
            height: 5,
          ),
          Container(
            child: Text(evento.programacao,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
            alignment: Alignment.center,
           height: 100,
            width: 500,
            decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.white,
               width: 5, 
          ),
           borderRadius: BorderRadius.circular(30)), 
          ),
        ]));
  }
}

