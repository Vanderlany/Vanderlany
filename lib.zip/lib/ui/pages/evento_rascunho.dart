import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';


class EventoRascunho extends StatelessWidget {
  const EventoRascunho ({Key? key}) : super(key: key);

  get crossAxisCount => null;


  @override
  Widget build(BuildContext context) {
    var onChanged;
    return Scaffold(
      backgroundColor: Color (0xFF766B6B),
       body: Column(children: [
         SizedBox(height: 70,),
       
         Text("Rascunho",
         textAlign: TextAlign.center,
             style: TextStyle(fontSize: 30, fontWeight: FontWeight.normal)),

      SizedBox(height: 400,),
                Container(     
                      child: Text("Carnaval 2022 Quinta                                                       22/02/2022 ás 19:00                                                             Produzido por F.  Lopes - fl0924146@gmail.com",
                  textAlign: TextAlign.left,
                   style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal),
                   ),
                  height: 100,
            width: 600,
              decoration: BoxDecoration(
            color: Color (0xFF766B6B),
             border: Border.all(
               color: Color (0xFFFFFFFF),
               width: 2, 
              ),
              borderRadius: BorderRadius.circular(10)), 
                 ),
                 SizedBox(height: 50,),
                 Text("Adicionar equipe                                                                 Adicionar descrição                                                    Cadastrar Local",
                  style: TextStyle( fontSize: 20, fontWeight: FontWeight.normal)),
                  
                   SizedBox(height: 150,),
                      Container(     
                      child: Text("Publicar evento",
                        textAlign: TextAlign.center,
                   style: TextStyle(fontSize: 25, fontWeight: FontWeight.normal)),

                  height: 50,
            width: 300,
              decoration: BoxDecoration(
            color: Colors.red,
             border: Border.all(
               color: Colors.red,
               width: 5, 
              ),
              borderRadius: BorderRadius.circular(50)),   
                 ),
                 SizedBox(height: 20,),
                 Container(
                   child:  Text("Exclur Evento",
                  textAlign: TextAlign.center,
                   style: TextStyle(fontSize: 25, fontWeight: FontWeight.normal)),
                         height: 50,
            width: 300,
              decoration: BoxDecoration(
            color: Colors.red,
             border: Border.all(
               color: Colors.red,
               width: 5, 
              ),
              borderRadius: BorderRadius.circular(50)),   
                 ),

    ]));
}
}