
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:fmvmevents/entities/entities.dart';

class EventoPerfil extends StatelessWidget {
  const EventoPerfil( {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    backgroundColor: Color(0xFFFFFFFF),
    body: Column(
      children: [
        SizedBox(height: 25,),
          Container(
            height: 50,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                color: Colors.black),
              ]
            ),
             child: Row(
             mainAxisAlignment: MainAxisAlignment.spaceBetween,
             children:[
             Padding(
               padding: EdgeInsets.all(8),
               child: Text("Ana Sousa",
               style: TextStyle(
               color: Colors.black,
               fontSize: 20,
               fontWeight: FontWeight.bold
               )
               )),
                  Container(
                    height: MediaQuery.of(context).size.height / 2.3,
                    color: Colors.white,
               child: Column(
                 crossAxisAlignment: CrossAxisAlignment.start,
                 children: [Row(
                 ),
                 SizedBox(height: 50,),
                    Container(
                     color: Colors.white,
                     width: MediaQuery.of(context).size.width / 2,
                      height: MediaQuery.of(context).size.height / 1,
                     child: Stack(
                       children: [
                         CircleAvatar(
                           radius: 50,
                                 backgroundImage: NetworkImage("https://1.bp.blogspot.com/-iFTsFNmQ2sA/Wz6OYx6PDzI/AAAAAAAARjY/JiRpxIFcIi8vKHt_9jRAMvWSTUpbrc3EQCLcBGAs/s1600/e74e8603a8aaa520d1de8fd22e70a872--anime-kimono-manga-anime.jpg",
                                 ),
                         )
                       ]),
                 )]),
                  )],
             ))])
               );
             
  }
}