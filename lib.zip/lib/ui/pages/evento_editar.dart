import'package:flutter/material.dart';

class EventoEditar extends StatelessWidget {
  const EventoEditar({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
          children: [
          Container(
            decoration: BoxDecoration(
            ),
            child: Container(
              width: double.infinity,
              height: 350.0,
              child: Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 100,),
                    CircleAvatar(
                      backgroundImage: NetworkImage("https://1.bp.blogspot.com/-iFTsFNmQ2sA/Wz6OYx6PDzI/AAAAAAAARjY/JiRpxIFcIi8vKHt_9jRAMvWSTUpbrc3EQCLcBGAs/s1600/e74e8603a8aaa520d1de8fd22e70a872--anime-kimono-manga-anime.jpg",
                    ),
                      radius: 50.0,
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    SizedBox(height: 20,),
                    Text(
                      "Ana",
                      style: TextStyle(
                        fontSize: 22.0,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),

               Container(    
                  child:  Text("Editar perfil",
                  textAlign: TextAlign.center,
                 style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal)),
            height: 30,
            width: 500,
              decoration: BoxDecoration(
             color: Colors.white,
             border: Border.all(
               color: Colors.black,
               width: 1,   
             ),
              borderRadius: BorderRadius.circular(5)), 
              ),
          
              Container(
              height: 30,
                  width: 30,
              alignment: Alignment.bottomLeft,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                 Icon(
                        Icons.favorite,
                        color: Colors.black,
                      ),
                  ]))
       
                  ]))
          ))]));
  }
}