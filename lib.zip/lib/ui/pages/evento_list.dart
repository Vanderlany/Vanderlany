

import 'package:flutter/material.dart';
import 'package:fmvmevents/data/evento_repository.dart';
import 'package:fmvmevents/entities/entities.dart';
import 'package:fmvmevents/evento_notificacao.dart';
import 'package:fmvmevents/ui/pages/evento_criar_conta.dart';
import 'package:fmvmevents/ui/pages/evento_detail.dart';
import 'package:fmvmevents/ui/pages/evento_explorar.dart';
import 'package:fmvmevents/ui/pages/evento_perfil.dart';
import 'package:fmvmevents/ui/pages/evento_rascunho.dart';



class EventsList extends StatefulWidget {
  EventsList( {Key? key}) : super(key: key);
 

@override
_EventsListState createState()=> _EventsListState();


}
class CustomSearchDelegate extends SearchDelegate{
List<String> searchTerms = [
'Água Branca',
'Angical do Piauí',
'São Pedro do Piauí',
'São Gonçalo',
'Amarante',
'Lagoinha',
'Hugo Napoleão',
'Regeneração',
];
@override
List<Widget> buildActions(BuildContext context){
return [
IconButton(
icon: const Icon(Icons.clear),
onPressed:() {
query = '';
},
)
];
}

@override
Widget buildLeading(BuildContext context){
return
IconButton(
icon: const Icon(Icons.arrow_back),
onPressed:() {
close(context, null);
},
);
}

@override
Widget buildResults(BuildContext context){
List<String> matchQuery = [];
for (var fruit in searchTerms){
if (fruit.toLowerCase().contains(query.toLowerCase())){
matchQuery.add(fruit);
}
}
return ListView.builder(
itemCount: matchQuery.length,
itemBuilder: (context, index) {
var result = matchQuery[index];
return ListTile(
title: Text(result),
);
},
);
}

@override
Widget buildSuggestions(BuildContext context){
List<String> matchQuery = [];
for (var fruit in searchTerms){
if (fruit.toLowerCase().contains(query.toLowerCase())){
matchQuery.add(fruit);
}
}
return ListView.builder(
itemCount: matchQuery.length,
itemBuilder: (context, index) {
var result = matchQuery[index];
return ListTile(
title: Text(result),
);
},
);
}
}

  @override
_EventsListState createState() => _EventsListState();
class _EventsListState extends State<EventsList>{
   int paginaAtual = 0;
   late PageController tela;
   final EventoRepository eventoRepository = EventoRepository();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Color(0xFF9400D3),
      title: Text("Pesquise aqui"),
actions: [
IconButton(
onPressed: () {
showSearch(
context: context,
delegate: CustomSearchDelegate(),);
},
icon: const Icon(Icons.search),
)],
      ),
      drawer: Drawer(
        child: ListView(
      padding: EdgeInsets.zero,
      children: const <Widget>[
        DrawerHeader(
          decoration: BoxDecoration(
            color: Colors.purple,
          ),
          child: Text(
            'FMVM EVENTS',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
            ),
          ),
        ),
        ListTile(
          leading: Icon(Icons.help),
          title: Text('Ajuda'),
        ),
        ListTile(
          leading: Icon(Icons.change_circle_rounded),
          title: Text('Sobre'),
        ),
        ListTile(
          leading: Icon(Icons.privacy_tip),
          title: Text('Privacidade'),
        ),
      
        ListTile(
          leading: Icon(Icons.check),
          title: Text('Enviar feedback'),
        ),
        ListTile(
          title: Text('Sair'),
        ),
      ],
    ),
      ),
      backgroundColor: Color(0xFFFFFFFF),
      body: Column(children: [
        PageView(
        controller: tela,
        children: [
          EventoCriarCont(),
          EventoExplorar(),
          EventoRascunho(),
          EventoNotificacao(),
          EventoPerfil()
        ],
      ),
        Stack(
          children: [
            Image.network(
              "https://diariodonordeste.verdesmares.com.br/image/contentid/policy:1.3147835:1634220198/Jo-o-Gomes.jpg?f=16x9&h=720&q=0.8&w=1280&\$p\$f\$h\$q\$w=da165d5",
            ),
            Container(
              height: 365,
                  width: 600,
              alignment: Alignment.bottomCenter,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Icon(
                        Icons.favorite,
                        color: Colors.black,
                      ),
                      Icon(
                        Icons.chat_bubble,
                         color: Colors.black,
                      ),
                      Icon(
                        Icons.save,
                        color: Colors.black,
                      ),
                      Icon(
                        Icons.share,
                        color: Colors.black,
                  ),
                ],
              ),
            )
          ],
        ),
        SizedBox(height: 10,),
        Text("Segunda, 27 de Janeiro. Às 22:00, Praça Pública",
         style: TextStyle(fontSize: 21, fontWeight: FontWeight.normal)),
          SizedBox(height: 10,),
        
        Expanded(
          child: _buildGridView(),
        ),
      ]),
    
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: paginaAtual,
        backgroundColor: Color(0xFF993399),
        items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home, color: Colors.white, size: 40), label: "Home", backgroundColor: Color(0xFF993399)),
        BottomNavigationBarItem(
            icon: Icon(Icons.explore, color: Colors.white, size: 40), label: "Explorar", backgroundColor: Color(0xFF993399)),
        BottomNavigationBarItem(
            icon: Icon(Icons.add_circle, color: Colors.white,size: 40), label: "Criar eventos", backgroundColor: Color(0xFF993399)),
             BottomNavigationBarItem(
            icon: Icon(Icons.notifications, color: Colors.white, size: 40), label: "Notificação", backgroundColor: Color(0xFF993399)),
             BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.white, size: 40), label: "Perfil", backgroundColor: Color(0xFF993399))

      ],
      onTap: (pagina) {
        tela.animateToPage(pagina,
         duration: Duration(milliseconds: 400), 
         curve: Curves.ease,
        );
      },
      ),
    );
  }


  Widget _buildGridView() {
    List<Evento> eventos = eventoRepository.list();
    return GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 1, crossAxisSpacing: 8, mainAxisSpacing: 8),
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                    builder: (context) => EventoDetail(eventos[index])),
              );
            },
            child: Column(children: [
              Stack(children: [
                Image.network(
                  eventos[index].banner,
                  height: 460,
                  width: 600,
                ),
                Container(
                  height: 450,
                  width: 400,
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: const [
                      Icon(
                        Icons.favorite,
                        color: Colors.black,
                      ),
                      Icon(
                        Icons.chat_bubble,
                         color: Colors.black,
                      ),
                      Icon(
                        Icons.save,
                        color: Colors.black,
                      ),
                      Icon(
                        Icons.share,
                        color: Colors.black,
                      ),
                    ],
                  ),
                )
              ]),
              SizedBox(height: 10,),
              Text(eventos[index].descricaoDoEvento,
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.normal)),
          SizedBox(height: 10,),
            ]),
          );
        },
        itemCount: eventos.length);
  }
}
