import 'package:fmvmevents/entities/entities.dart';

class EventoRepository {
List<Evento> list() {
  return[
Evento("https://storage.stwonline.com.br/180graus/uploads/ckeditor/pictures/2131513/whatsapp-image-2019-06-15-at-15.12.14.jpeg","Segunda, 22 de janeiro","Local","Angical do Piauí","Descrição do Evento","Hoje haverá","Programção","20h ocorrerá", "Segunda, 22 de janeiro" ),
  Evento("https://storage.stwonline.com.br/180graus/uploads/ckeditor/pictures/2131513/whatsapp-image-2019-06-15-at-15.12.14.jpeg","Terça, 23 de janeiro","Local", "Água Branca,Piauí","Descrição do Evento","Teremos frevo","Programação","08h ocorrerá", "Terca, 23 de janeiro",),
  Evento("https://storage.stwonline.com.br/180graus/uploads/ckeditor/pictures/2131513/whatsapp-image-2019-06-15-at-15.12.14.jpeg", "Quarta 24 de janero","Local","São Pedro do Piauí","Descrição do Evento", "Anitta","Programação","22h ocorrerá", "Quarta, 24 de janeiro",),
   Evento("https://storage.stwonline.com.br/180graus/uploads/ckeditor/pictures/2131513/whatsapp-image-2019-06-15-at-15.12.14.jpeg","Quinta, 25 de janeiro","Local", "Lagoinha","Descrição do Evento","Aniversário da city", "Programação","21h ocorrerá", "Quinta, 25 de janeiro" ),
  ];
}

}